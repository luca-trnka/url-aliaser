package com.gfa.urlaliaser.models;

public class SecretCodeIdentificator {
    private String secretCode;

    public SecretCodeIdentificator() {
        this.secretCode = secretCode;
    }


    public String getSecretCode() {
        return secretCode;
    }

    public void setSecretCode(String secretCode) {
        this.secretCode = secretCode;
    }
}
