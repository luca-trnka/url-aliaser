package com.gfa.urlaliaser.services;

public interface LinkEntryService {
    public String generateSecretCode();
}
