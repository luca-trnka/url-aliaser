package com.gfa.urlaliaser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlAliaserApplicationTests {

	@Test
	void contextLoads() {
	}

}
